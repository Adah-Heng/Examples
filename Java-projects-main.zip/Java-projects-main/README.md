# Java-projects
1. Section one invoice app
. does invoice totals

2. Section 2 bank app. tells user amount of money in account

3. Section 3 BB_Scoreboard_App is an application that allows people to set up a team, players, and the players jersey number.<br>
BB_Scoreboard_App adds players into the teams, throws error if you can not add the player, and has the user interface.<br>
Player is a class that sets up the player and their jersey number. Throwing exception when the jersey number is out of a range of 0-99.<br>
Player also keeps track of name, jersey, foul, freeThrow, twoPointer, threePointer. Shot in player keeps track of each type of shots. <br>
Player getPoints is an equation that calulates the amount of points the player made. Player displayStats displays fouls and points and <br>
equals is a boolean verify two players are the same only by jersey number.<br>
Team keeps track of the team name and players using a arraylist. The team name is set up, adds players to the list, and throws an expetion for<br>
jersey to make sure that there are no duplicates. Team displayDetailStats displayes the player's name, jersey number, fouls, free throws, two pointers,<br>
three pointer and the total points. Team displayTeamStats displays teamPoints and teamFouls. TeamFouls keeps track of each players fouls and adds them <br>
together for the teams fouls. Teampoints keeps track of each players points and adds them together for the teams points. Input takes care of the user's<br>
input.

4. The Zoo_Keeper_App keeps track of multiple differnt kinds of animals. The main section allows the creation of animals keeping track of the weight, <br>
 birth date, type, and id of the animal. The bird allows the keepers to track the same as animal, but includes wing span. The bird has two subclasses<br>
 called sparrow and chicken they do the same thing as bird. Though, sparrow can fly, glide, and soar. The chicken can not to do any of those. Fish <br>
 does the same thing as bird, but instead it includes water types such as fresh, salt, or unknown water. The flying fish is the only fish that can <br>
 fly, soar, or glide. The chicken, sparrow, flying fish, and guppys can see if the animal is eating.

5. The JavaFXCalculator is a calculator that has the numbers zero through nine. The calculator also has buttons for four differnet types of memory<br>
such as memory plus, memory minus, memory recall, and memory clear. Other buttons include all clear, multiplication, division, addition,<br>
subtraction, square root, power, a back button, and a decimal. The buttons are aranged in the center in four columns and six rows. The top has<br>
the input number and the calucalted number in a box. The memory is deplayed on the bottom of the display. The code uses text to display the <br> 
memory. The event handler is where the input from the buttons and displays the number some of the inputs call compute. Compute is where all <br>
of computations are made. Start is where all of the display happends.
