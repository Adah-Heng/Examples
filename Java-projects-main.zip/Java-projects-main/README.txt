# Java-projects
1. Section one invoice app
. does invoice totals

2. Section 2 bank app. tells user amount of money in account

3. Section 3 BB_Scoreboard_App is an application that allows people to set up a team, players, and the players jersey number.<br>
BB_Scoreboard_App adds players into the teams, throws error if you can not add the player, and has the user interface.<br>
Player is a class that sets up the player and their jersey number. Throwing exception when the jersey number is out of a range of 0-99.<br>
Player also keeps track of name, jersey, foul, freeThrow, twoPointer, threePointer. Shot in player keeps track of each type of shots. <br>
Player getPoints is an equation that calulates the amount of points the player made. Player displayStats displays fouls and points and <br>
equals is a boolean verify two players are the same only by jersey number.<br>
Team keeps track of the team name and players using a arraylist. The team name is set up, adds players to the list, and throws an expetion for<br>
jersey to make sure that there are no duplicates. Team displayDetailStats displayes the player's name, jersey number, fouls, free throws, two pointers,<br>
three pointer and the total points. Team displayTeamStats displays teamPoints and teamFouls. TeamFouls keeps track of each players fouls and adds them <br>
together for the teams fouls. Teampoints keeps track of each players points and adds them together for the teams points. Input takes care of the user's<br>
input.