
/**
 * Class used to create Account objects
 * @author Adahm
 *
 */
public class Account {

	/**
	 * The last account number used for all accounts in my bank
	 * this is a class level field - share across all accounts
	 */
	private static int lastNumber = 0;

	// instance level fields - unique per account
	// a field can also be called attribute or property
	/**
	 * The unique account number for my bank
	 */
	private int number;
	private String firstName;
	private String lastName;
	private double balance;

	// default constructor that will return a unique account object 
	/**
	 * The default constructor automatically assigns the next account number
	 * and default field values and return a unique object
	 */
	public Account() {
		System.out.println("Default constructor");

		this.number = ++Account.lastNumber;
		this.balance = 0;
		this.firstName = "Unknown";
		this.lastName = "Unknown";
	} // end of default

	// overload constructor that allows setting the object's fields
	/**The overload constructor calls the default constructor and allows over riding default values
	 * and return a unique object
	 * @param firstName the account owner's first name
	 * @param lastName the account owner's last name
	 * @param balance the account balance
	 */
	public Account(String firstName, String lastName, double balance) {
		this(); // call the default constructor

		// can not run this before calling default constructor
		System.out.println("Overload constructor");

		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
	} // end of overload constructor

	/**
	 * Allows getting the account owner's name
	 * @return account owner's name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * allows changing account owner's first name 
	 * @param firstName the account owner's first name
	 */
	public void setFirstName(String firstName) {
		if(firstName == "")
			System.out.println("Invaalid firstname. Name can not be empty.");
		else
			this.firstName = firstName;
		this.firstName = firstName;
	}

	/**
	 * Allows getting the account owner's last name
	 * @return last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * allows changing account owner's last name 
	 * @param lastName the account owner's last name
	 */
	public void setLastName(String lastName) {
		if(lastName == "")
			System.out.println("Invaalid lastname. Name can not be empty.");
		else
			this.lastName = lastName;
		this.lastName = lastName;
	}
	/**
	 * Allows getting account balance
	 * @param  
	 * @return the account balance
	 */
	public double getBalance() {
		return balance;
	}
	/**
	 * Allows depositing money into account but only if amount is greater than 0
	 * @param amount to deposit
	 */
	public void withdrawl(double amount) {
		if(amount <= 0)
			System.out.println("Invalid withdrawal [" + amount +"] Can not be more than balance");
		else if(amount > this.balance)
			System.out.println("Valid withdrawal [" + amount +"] good balance");
		else
			this.balance -= amount;
	}

	/**
	 * Allows depositing money into account but only if amount is greater than 0
	 * @param amount to deposit
	 */
	public void deposit(double amount) {
		if(amount <= 0)
			System.out.println("Invalid deposit [" + amount +"] Can not be less or equal to 0");
		else if(amount > this.balance)
			System.out.println("Valid deposit [" + amount +"] good balance");
		else
			this.balance += amount;
	}
	/**
	 * Allows getting the last account number used
	 * @return the last account number used
	 */
	public static int getLastNumber() {
		return lastNumber;
	}

	/**
	 * Allows getting the account number
	 * @return account number
	 */
	public int getNumber() {
		return number;
	}



} // end of Account class
